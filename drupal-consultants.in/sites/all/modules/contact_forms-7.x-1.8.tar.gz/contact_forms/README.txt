
CONTACT_FORMS.MODULE

Overview
--------
This module expands the features of the site wide
contact form. It eliminates the need for the drop
down category menu by generating a form, and a
unique path, for each of the contact form categories.

The path 'contact/{category}' generates a contact form
for that category with a title = 'Contact {category}'.
e.g. path 'contact/Jill Jones' generates a contact form
for the category 'Jill Jones' with a title = 'Contact Jill Jones'. You can use underscore "_" or a dash "-" instead of spaces.

If a path is entered that does not have a category you
can specify a page to redirect to. The default fall back
path is contact.

To define the subject of the generated form the path is as follows
'contact/{category}/Subject goes here'
e.g. path 'contact/Jill Jones/Enquiry about Sales' generates a contact form
for the category 'Jill Jones' with a title = 'Contact jill Jones' and the subject
'Enquiry about Sales'.

Multilingual Sites
------------------
For use with the Internationalization module enable the Contact forms translation module and for more info see the README file in the contact_forms_int folder which is in the contact_forms folder

Contact Field Compatability
-------------
This module works with the contact_field module but needs to be enabled after the contact_field module. If you are having problems with the added fields not displaying in the correct order, disable and enable the contact_forms module and the problem should be solved.

This problem is caused by the weight of contact_field module in the System table needing to be greater than the weight of the contact_forms module. When the contact_forms module is enabled it compares the weights and changes the weight of the contact_field module.


Requirements
------------
contact.module must be enabled.


Installation
------------
  1. Copy contact_forms folder to sites/all/modules/.
  2. Check contact.module is enabled
  3. Enable Contact Forms module


Usage
-----
This module was written for sites that have many email
contacts where you want a page with information about
the people / departments etc with links to their individual
contact forms.

Create a "Contact Directory" page with a path like 'directory'
and lay it out how you would like it. Links to the forms can
be made with the following code [using the drupal link function]
<?php
print l('Email Jill Jones', 'contact/Jill Jones');
?>
This page can be set as the fall back page if a contact/category
path is entered that doesn't exist.


Snippets
--------
1. The "old" contact/list page
This will give you a list of links to the contact forms.

<!-- start snippet -->
<p>Who would you like to contact?</p>
<?php
  $result = db_query('SELECT * FROM {contact} ORDER BY weight, category');
  print '<div id="contact-list">';
  print '<div class="item-list"><ul>';
  while ($contact = db_fetch_object($result)) {
    $cleanurl = str_replace(' ', '_' ,$contact->category);
    print '<li>'. l($contact->category , 'contact/'. $cleanurl) .'</li>';
  }
  print '</div>';
  print '</div>';
?>
<!-- end snippet -->


Credits
-------
Thanks to the following people who have helped with suggestions and code:
nancyw
alienbrain
incrn8
joachim
mfredrickson
jandd
arcaneadam
Rob C